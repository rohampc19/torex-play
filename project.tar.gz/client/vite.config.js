import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { port: 5173, proxy: { '/api': 'http://localhost:4000', '/socket.io': { target:'http://localhost:4000', ws:true } } },
  build: { target: 'es2022', sourcemap: true }
});
